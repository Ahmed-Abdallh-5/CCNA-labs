# Cisco DHCP Server Lab

## Overview

A hands-on networking lab focused on configuring a Cisco router as a DHCP server and verifying dynamic IP address assignment using GNS3, VMware, and Wireshark.

## Lab Environment

- GNS3
- Cisco IOS Router
- GNS3 Ethernet Switch
- VMware Workstation
- VMware VMnet2
- Windows Client
- Wireshark

## Network Topology

![DHCP Topology](screenshots/dhcp-topology.png)

Network: `192.168.1.0/24`

DHCP Server: `192.168.1.1`

## DHCP Configuration

Configured the Cisco router as a DHCP server.

```cisco
interface f0/0
 ip address 192.168.1.1 255.255.255.0
 no shutdown

ip dhcp excluded-address 192.168.1.2 192.168.1.10
ip dhcp excluded-address 192.168.1.100

ip dhcp pool LAN
 network 192.168.1.0 /24
 default-router 192.168.1.1
 dns-server 8.8.8.8
