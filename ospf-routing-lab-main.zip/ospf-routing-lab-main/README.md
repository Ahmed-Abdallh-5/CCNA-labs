# OSPF Routing Lab

## Overview

A hands-on Cisco OSPF routing lab built using GNS3 to practice dynamic routing, OSPF neighbor adjacency, route exchange, and network connectivity between multiple routers.

The lab consists of three Cisco routers connected in a triangular topology, with OSPF configured to dynamically exchange routing information between the routers.

---

## Lab Environment

- GNS3
- Cisco IOS Routers
- OSPF
- IPv4
- Serial Interfaces
- FastEthernet Interfaces

---

## Network Topology

The lab consists of three routers:

- R1
- R2
- R3

The routers are connected using the following networks:

```text
R1 ↔ R2
10.0.0.0/30

R1 ↔ R3
11.0.0.0/30

R2 ↔ R3
12.0.0.0/24
